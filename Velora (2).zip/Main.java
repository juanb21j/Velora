import java.util.ArrayList;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Clase principal de Velora - Red Social para Ciclistas Aficionados.
 * Gestiona el menú, la lógica de la aplicación y la persistencia en CSV.
 *
 * @author Juan José Bedoya
 * @version 1.0
 */
public class Main {

    // ── Constantes de archivos CSV ────────────────────────────────────────────

    /** Ruta del archivo de usuarios */
    static final String ARCHIVO_USUARIOS = "usuarios.csv";

    /** Ruta del archivo de rutas */
    static final String ARCHIVO_RUTAS = "rutas.csv";

    // ── Estado global de la aplicación ────────────────────────────────────────

    static Scanner scanner = new Scanner(System.in);

    /** Lista de todos los usuarios registrados */
    static ArrayList<Usuario> usuarios = new ArrayList<>();

    /** Lista global de todas las rutas registradas */
    static ArrayList<Ruta> rutas = new ArrayList<>();

    // ── Punto de entrada ──────────────────────────────────────────────────────

    /**
     * Método principal. Carga los datos al iniciar y los guarda al salir.
     *
     * @param args argumentos de línea de comandos (no se usan)
     */
    public static void main(String[] args) {

        cargarDatos();

        boolean running = true;

        while (running) {

            mostrarMenu();

            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {

                case 1:
                    registrarUsuario();
                    break;

                case 2:
                    agregarRutaUsuario();
                    break;

                case 3:
                    conectarCiclistas();
                    break;

                case 4:
                    visualizarDatos();
                    break;

                case 5:
                    buscarCiclista();
                    break;

                case 6:
                    listarCiclistas();
                    break;

                case 7:
                    listarRutas();
                    break;

                case 8:
                    estadisticasUsuario();
                    break;

                case 9:
                    guardarDatos();
                    break;

                case 0:
                    guardarDatos();
                    running = false;
                    System.out.println("\nCerrando Velora...");
                    break;

                default:
                    System.out.println("\nOpción inválida.");

            }

        }

    }

    // ── Menú ──────────────────────────────────────────────────────────────────

    /**
     * Muestra el menú principal en consola.
     */
    public static void mostrarMenu() {

        System.out.println("\n==================================");
        System.out.println(" RED SOCIAL CICLISTAS - VELORA");
        System.out.println("==================================");
        System.out.println("1. Registrar nuevo usuario");
        System.out.println("2. Añadir ruta a usuario");
        System.out.println("3. Conectar con otro ciclista");
        System.out.println("4. Visualizar datos");
        System.out.println("5. Buscar ciclista");
        System.out.println("6. Listar ciclistas");
        System.out.println("7. Lista rutas (leaderboard)");
        System.out.println("8. Estadísticas de usuario");
        System.out.println("9. Guardar datos");
        System.out.println("0. Salir");
        System.out.print("\nSeleccione una opción: ");

    }

    // ── Ingreso de datos ──────────────────────────────────────────────────────

    /**
     * Registra un nuevo usuario solicitando sus datos por consola.
     */
    public static void registrarUsuario() {

        System.out.println("\n===== REGISTRO USUARIO =====");

        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Edad: ");
        int edad = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Tipo de ciclismo (Ruta, MTB, Gravel, Urbano): ");
        String tipo = scanner.nextLine();

        System.out.print("Ciudad: ");
        String ciudad = scanner.nextLine();

        Usuario usuario = new Usuario(nombre, edad, tipo, ciudad);
        usuarios.add(usuario);

        System.out.println("\nUsuario registrado correctamente.");

    }

    /**
     * Agrega una ruta al perfil de un usuario existente.
     */
    public static void agregarRutaUsuario() {

        if (usuarios.isEmpty()) {
            System.out.println("\nNo hay usuarios registrados.");
            return;
        }

        System.out.println("\n===== AÑADIR RUTA =====");
        mostrarUsuarios();

        System.out.print("\nSeleccione usuario: ");
        int index = scanner.nextInt();
        scanner.nextLine();

        if (index < 1 || index > usuarios.size()) {
            System.out.println("\nÍndice inválido.");
            return;
        }

        Usuario usuario = usuarios.get(index - 1);

        System.out.print("Nombre ruta: ");
        String nombreRuta = scanner.nextLine();

        System.out.print("Tipo ruta (Llano, Montaña, Carretera): ");
        String tipoRuta = scanner.nextLine();

        System.out.print("Distancia (km): ");
        double distancia = scanner.nextDouble();

        System.out.print("Dificultad (1-5): ");
        int dificultad = scanner.nextInt();

        System.out.print("Tiempo (minutos): ");
        int tiempo = scanner.nextInt();
        scanner.nextLine();

        Ruta ruta = new Ruta(nombreRuta, tipoRuta, distancia, dificultad, tiempo);
        usuario.getRutas().add(ruta);
        rutas.add(ruta);

        System.out.println("\nRuta agregada correctamente.");

    }

    /**
     * Conecta dos usuarios como amigos ciclistas (relación bidireccional).
     */
    public static void conectarCiclistas() {

        if (usuarios.size() < 2) {
            System.out.println("\nSe necesitan mínimo 2 usuarios.");
            return;
        }

        System.out.println("\n===== CONECTAR CICLISTAS =====");
        mostrarUsuarios();

        System.out.print("\nSeleccione usuario 1: ");
        int i1 = scanner.nextInt();

        System.out.print("Seleccione usuario 2: ");
        int i2 = scanner.nextInt();
        scanner.nextLine();

        if (i1 < 1 || i1 > usuarios.size() || i2 < 1 || i2 > usuarios.size() || i1 == i2) {
            System.out.println("\nSelección inválida.");
            return;
        }

        Usuario u1 = usuarios.get(i1 - 1);
        Usuario u2 = usuarios.get(i2 - 1);

        u1.getAmigos().add(u2);
        u2.getAmigos().add(u1);

        System.out.println("\nCiclistas conectados correctamente.");

    }

    // ── Visualización ─────────────────────────────────────────────────────────

    /**
     * Muestra todos los usuarios con sus rutas y amigos.
     * También permite filtrar por tipo de ciclismo.
     */
    public static void visualizarDatos() {

        System.out.println("\n===== VISUALIZACIÓN =====");
        System.out.println("1. Todos los usuarios");
        System.out.println("2. Filtrar por tipo de ciclismo");
        System.out.print("Opción: ");

        int opcion = scanner.nextInt();
        scanner.nextLine();

        String filtro = null;

        if (opcion == 2) {
            System.out.print("Tipo (Ruta, MTB, Gravel, Urbano): ");
            filtro = scanner.nextLine();
        }

        boolean hayResultados = false;

        for (Usuario usuario : usuarios) {

            // Si hay filtro, saltar usuarios que no coincidan
            if (filtro != null && !usuario.getTipoCiclismo().equalsIgnoreCase(filtro)) {
                continue;
            }

            hayResultados = true;

            System.out.println("\n----------------------------------");
            System.out.println("Nombre: " + usuario.getNombre());
            System.out.println("Edad: " + usuario.getEdad());
            System.out.println("Tipo ciclismo: " + usuario.getTipoCiclismo());
            System.out.println("Ciudad: " + usuario.getCiudad());

            System.out.println("\nAmigos:");
            if (usuario.getAmigos().isEmpty()) {
                System.out.println("  (sin amigos aún)");
            } else {
                for (Usuario amigo : usuario.getAmigos()) {
                    System.out.println("  - " + amigo.getNombre());
                }
            }

            System.out.println("\nRutas:");
            if (usuario.getRutas().isEmpty()) {
                System.out.println("  (sin rutas aún)");
            } else {
                for (Ruta ruta : usuario.getRutas()) {
                    System.out.println("  - " + ruta.getNombre()
                            + " | " + ruta.getDistancia() + " km"
                            + " | " + ruta.getTiempo() + " min"
                            + " | Dificultad: " + ruta.getDificultad());
                }
            }

        }

        if (!hayResultados) {
            System.out.println("\nNo se encontraron usuarios con ese criterio.");
        }

    }

    /**
     * Muestra estadísticas acumuladas de un usuario:
     * total de rutas, km recorridos, tiempo total y dificultad promedio.
     */
    public static void estadisticasUsuario() {

        if (usuarios.isEmpty()) {
            System.out.println("\nNo hay usuarios registrados.");
            return;
        }

        System.out.println("\n===== ESTADÍSTICAS =====");
        mostrarUsuarios();
        System.out.print("\nSeleccione usuario: ");
        int index = scanner.nextInt();
        scanner.nextLine();

        if (index < 1 || index > usuarios.size()) {
            System.out.println("\nÍndice inválido.");
            return;
        }

        Usuario usuario = usuarios.get(index - 1);
        ArrayList<Ruta> rutasUsuario = usuario.getRutas();

        if (rutasUsuario.isEmpty()) {
            System.out.println("\nEste usuario no tiene rutas registradas.");
            return;
        }

        // Cálculo de estadísticas
        double totalKm = 0;
        int totalMinutos = 0;
        int sumaDificultad = 0;

        for (Ruta ruta : rutasUsuario) {
            totalKm += ruta.getDistancia();
            totalMinutos += ruta.getTiempo();
            sumaDificultad += ruta.getDificultad();
        }

        double promDificultad = (double) sumaDificultad / rutasUsuario.size();
        double velocidadPromedio = (totalMinutos > 0) ? (totalKm / totalMinutos) * 60 : 0;

        System.out.println("\n--- Estadísticas de " + usuario.getNombre() + " ---");
        System.out.println("Total rutas completadas : " + rutasUsuario.size());
        System.out.printf("Kilómetros totales      : %.2f km%n", totalKm);
        System.out.println("Tiempo total            : " + totalMinutos + " min");
        System.out.printf("Velocidad promedio      : %.1f km/h%n", velocidadPromedio);
        System.out.printf("Dificultad promedio     : %.1f / 5%n", promDificultad);

    }

    // ── Búsqueda ──────────────────────────────────────────────────────────────

    /**
     * Menú de búsqueda: por nombre, por ciudad o por tipo de ciclismo.
     */
    public static void buscarCiclista() {

        System.out.println("\n===== BUSCAR CICLISTA =====");
        System.out.println("1. Buscar por nombre");
        System.out.println("2. Buscar por ciudad");
        System.out.println("3. Buscar por tipo de ciclismo");
        System.out.print("Opción: ");

        int opcion = scanner.nextInt();
        scanner.nextLine();

        switch (opcion) {
            case 1: buscarPorNombre(); break;
            case 2: buscarPorCiudad(); break;
            case 3: buscarPorTipo(); break;
            default: System.out.println("\nOpción inválida.");
        }

    }

    /**
     * Búsqueda lineal de usuarios por nombre (ignora mayúsculas).
     */
    private static void buscarPorNombre() {

        System.out.print("Ingrese nombre: ");
        String busqueda = scanner.nextLine();

        boolean encontrado = false;

        for (Usuario usuario : usuarios) {
            if (usuario.getNombre().equalsIgnoreCase(busqueda)) {
                imprimirResumenUsuario(usuario);
                encontrado = true;
            }
        }

        if (!encontrado) {
            System.out.println("\nUsuario no encontrado.");
        }

    }

    /**
     * Búsqueda lineal de usuarios por ciudad (ignora mayúsculas).
     */
    private static void buscarPorCiudad() {

        System.out.print("Ingrese ciudad: ");
        String ciudad = scanner.nextLine();

        boolean encontrado = false;

        for (Usuario usuario : usuarios) {
            if (usuario.getCiudad().equalsIgnoreCase(ciudad)) {
                imprimirResumenUsuario(usuario);
                encontrado = true;
            }
        }

        if (!encontrado) {
            System.out.println("\nNo hay ciclistas en esa ciudad.");
        }

    }

    /**
     * Búsqueda lineal de usuarios por tipo de ciclismo (ignora mayúsculas).
     */
    private static void buscarPorTipo() {

        System.out.print("Tipo (Ruta, MTB, Gravel, Urbano): ");
        String tipo = scanner.nextLine();

        boolean encontrado = false;

        for (Usuario usuario : usuarios) {
            if (usuario.getTipoCiclismo().equalsIgnoreCase(tipo)) {
                imprimirResumenUsuario(usuario);
                encontrado = true;
            }
        }

        if (!encontrado) {
            System.out.println("\nNo hay ciclistas con ese tipo.");
        }

    }

    /**
     * Imprime un resumen breve de un usuario en consola.
     *
     * @param usuario el usuario a mostrar
     */
    private static void imprimirResumenUsuario(Usuario usuario) {

        System.out.println("\nUsuario encontrado:");
        System.out.println("  Nombre  : " + usuario.getNombre());
        System.out.println("  Ciudad  : " + usuario.getCiudad());
        System.out.println("  Tipo    : " + usuario.getTipoCiclismo());
        System.out.println("  Edad    : " + usuario.getEdad());
        System.out.println("  Rutas   : " + usuario.getRutas().size());
        System.out.println("  Amigos  : " + usuario.getAmigos().size());

    }

    // ── Ordenamiento ──────────────────────────────────────────────────────────

    /**
     * Ordena los usuarios con algoritmo de burbuja según criterio elegido:
     * nombre, edad o tipo de ciclismo.
     */
    public static void listarCiclistas() {

        if (usuarios.isEmpty()) {
            System.out.println("\nNo hay usuarios registrados.");
            return;
        }

        System.out.println("\n===== LISTAR CICLISTAS =====");
        System.out.println("Ordenar por:");
        System.out.println("1. Nombre");
        System.out.println("2. Edad");
        System.out.println("3. Tipo de ciclismo");
        System.out.print("Opción: ");

        int criterio = scanner.nextInt();
        scanner.nextLine();

        // Burbuja genérica con comparador según criterio
        for (int i = 0; i < usuarios.size() - 1; i++) {

            for (int j = 0; j < usuarios.size() - i - 1; j++) {

                boolean intercambiar = false;

                if (criterio == 1) {
                    intercambiar = usuarios.get(j).getNombre()
                            .compareToIgnoreCase(usuarios.get(j + 1).getNombre()) > 0;
                } else if (criterio == 2) {
                    intercambiar = usuarios.get(j).getEdad() > usuarios.get(j + 1).getEdad();
                } else if (criterio == 3) {
                    intercambiar = usuarios.get(j).getTipoCiclismo()
                            .compareToIgnoreCase(usuarios.get(j + 1).getTipoCiclismo()) > 0;
                }

                if (intercambiar) {
                    Usuario temp = usuarios.get(j);
                    usuarios.set(j, usuarios.get(j + 1));
                    usuarios.set(j + 1, temp);
                }

            }

        }

        System.out.println("\n===== CICLISTAS ORDENADOS =====");
        mostrarUsuarios();

    }

    /**
     * Ordena todas las rutas por tiempo (burbuja ascendente) y muestra el leaderboard.
     */
    public static void listarRutas() {

        if (rutas.isEmpty()) {
            System.out.println("\nNo hay rutas registradas.");
            return;
        }

        // Ordenamiento burbuja por tiempo ascendente
        for (int i = 0; i < rutas.size() - 1; i++) {

            for (int j = 0; j < rutas.size() - i - 1; j++) {

                if (rutas.get(j).getTiempo() > rutas.get(j + 1).getTiempo()) {
                    Ruta temp = rutas.get(j);
                    rutas.set(j, rutas.get(j + 1));
                    rutas.set(j + 1, temp);
                }

            }

        }

        System.out.println("\n===== LEADERBOARD =====");
        System.out.printf("%-4s %-20s %-12s %-10s %-12s %-5s%n",
                "#", "Ruta", "Tipo", "Dist(km)", "Tiempo(min)", "Dif");
        System.out.println("---------------------------------------------------------------");

        for (int i = 0; i < rutas.size(); i++) {
            Ruta r = rutas.get(i);
            System.out.printf("%-4d %-20s %-12s %-10.1f %-12d %-5d%n",
                    (i + 1), r.getNombre(), r.getTipo(),
                    r.getDistancia(), r.getTiempo(), r.getDificultad());
        }

    }

    // ── Utilidades ────────────────────────────────────────────────────────────

    /**
     * Imprime en consola la lista numerada de usuarios registrados.
     */
    public static void mostrarUsuarios() {

        for (int i = 0; i < usuarios.size(); i++) {
            System.out.println((i + 1) + ". " + usuarios.get(i).getNombre()
                    + " (" + usuarios.get(i).getCiudad() + ")");
        }

    }

    // ── Persistencia CSV ──────────────────────────────────────────────────────

    /**
     * Guarda todos los usuarios y rutas en archivos CSV.
     * Formato usuarios.csv: nombre,edad,tipoCiclismo,ciudad
     * Formato rutas.csv: nombreRuta,tipo,distancia,dificultad,tiempo,nombreUsuarioDueño
     */
    public static void guardarDatos() {

        // Guardar usuarios
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ARCHIVO_USUARIOS))) {

            for (Usuario u : usuarios) {
                bw.write(u.getNombre() + ","
                        + u.getEdad() + ","
                        + u.getTipoCiclismo() + ","
                        + u.getCiudad());
                bw.newLine();
            }

        } catch (IOException e) {
            System.out.println("\nError guardando usuarios: " + e.getMessage());
        }

        // Guardar rutas (con nombre del dueño para reconstruir la asociación)
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ARCHIVO_RUTAS))) {

            for (Usuario u : usuarios) {
                for (Ruta r : u.getRutas()) {
                    bw.write(r.getNombre() + ","
                            + r.getTipo() + ","
                            + r.getDistancia() + ","
                            + r.getDificultad() + ","
                            + r.getTiempo() + ","
                            + u.getNombre());
                    bw.newLine();
                }
            }

        } catch (IOException e) {
            System.out.println("\nError guardando rutas: " + e.getMessage());
        }

        System.out.println("\nDatos guardados correctamente.");

    }

    /**
     * Carga usuarios y rutas desde los archivos CSV al iniciar la aplicación.
     * Si los archivos no existen, inicia con listas vacías.
     */
    public static void cargarDatos() {

        // Cargar usuarios
        try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO_USUARIOS))) {

            String linea;

            while ((linea = br.readLine()) != null) {

                String[] partes = linea.split(",");

                if (partes.length == 4) {
                    String nombre = partes[0];
                    int edad = Integer.parseInt(partes[1]);
                    String tipo = partes[2];
                    String ciudad = partes[3];
                    usuarios.add(new Usuario(nombre, edad, tipo, ciudad));
                }

            }

            System.out.println("Usuarios cargados: " + usuarios.size());

        } catch (IOException e) {
            // Archivo no existe aún, es normal en la primera ejecución
        }

        // Cargar rutas y asociarlas al usuario dueño
        try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO_RUTAS))) {

            String linea;

            while ((linea = br.readLine()) != null) {

                String[] partes = linea.split(",");

                if (partes.length == 6) {
                    String nombreRuta = partes[0];
                    String tipoRuta = partes[1];
                    double distancia = Double.parseDouble(partes[2]);
                    int dificultad = Integer.parseInt(partes[3]);
                    int tiempo = Integer.parseInt(partes[4]);
                    String nombreDueno = partes[5];

                    Ruta ruta = new Ruta(nombreRuta, tipoRuta, distancia, dificultad, tiempo);
                    rutas.add(ruta);

                    // Asociar ruta al usuario dueño
                    for (Usuario u : usuarios) {
                        if (u.getNombre().equals(nombreDueno)) {
                            u.getRutas().add(ruta);
                            break;
                        }
                    }

                }

            }

            System.out.println("Rutas cargadas: " + rutas.size());

        } catch (IOException e) {
            // Archivo no existe aún
        }

    }

}
