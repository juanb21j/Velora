public class Ruta {

    private String nombre;

    private String tipo;

    private double distancia;

    private int dificultad;

    private int tiempo;

    public Ruta(
            String nombre,
            String tipo,
            double distancia,
            int dificultad,
            int tiempo
    ) {

        this.nombre = nombre;

        this.tipo = tipo;

        this.distancia = distancia;

        this.dificultad = dificultad;

        this.tiempo = tiempo;

    }

    public String getNombre() {

        return nombre;

    }

    public String getTipo() {

        return tipo;

    }

    public double getDistancia() {

        return distancia;

    }

    public int getDificultad() {

        return dificultad;

    }

    public int getTiempo() {

        return tiempo;

    }

}