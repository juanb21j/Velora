import java.util.ArrayList;

public class Usuario {

    private String nombre;

    private int edad;

    private String tipoCiclismo;

    private String ciudad;

    private ArrayList<Ruta> rutas;

    private ArrayList<Usuario> amigos;

    public Usuario(
            String nombre,
            int edad,
            String tipoCiclismo,
            String ciudad
    ) {

        this.nombre = nombre;

        this.edad = edad;

        this.tipoCiclismo = tipoCiclismo;

        this.ciudad = ciudad;

        rutas = new ArrayList<>();

        amigos = new ArrayList<>();

    }

    public String getNombre() {

        return nombre;

    }

    public int getEdad() {

        return edad;

    }

    public String getTipoCiclismo() {

        return tipoCiclismo;

    }

    public String getCiudad() {

        return ciudad;

    }

    public ArrayList<Ruta> getRutas() {

        return rutas;

    }

    public ArrayList<Usuario> getAmigos() {

        return amigos;

    }

}